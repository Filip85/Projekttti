package com.example.narucime

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

class MakeAnAppointment : Fragment() {

    companion object {
        fun newInstance() : MakeAnAppointment {
            return MakeAnAppointment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.make_an_appointment, container, false)
        return view
    }
}